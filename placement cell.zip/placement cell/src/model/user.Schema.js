import mongoose from "mongoose";
import Schema from "mongoose";

const userschema= mongoose.Schema({
    name: {type:String},
    number:{type: Number},
    email:{type:String},
    password: {type:String}
});

export const userModel= mongoose.model("User", userschema);


