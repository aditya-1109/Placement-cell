
import mongoose from "mongoose";

const studentSchema=mongoose.Schema({
    name:{type:String, required:true},
    batch: {type: Number, maxlength: 4, required: true},
    college: {type: String, required: true},
    status: {type: String, required: true, enum:["placed", "not_placed"]},
    score:{
        DSAscore:{type:Number, required: true},
        webDscore:{type:Number, required: true},
        reactScore:{type: Number, required:true},
    },
});

export const studentModel= mongoose.model("student", studentSchema);

