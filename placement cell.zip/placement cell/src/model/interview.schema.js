import mongoose from "mongoose";

const interviewSchema= mongoose.Schema({
    studentID:{type:String,minlength: 1,required: true},
    date:{type:Date, required: true},
    company:{type:String, required: true},
    result: {type: String, required: true, enum:["PASS", "FAIL", "OnHold", "Didn't Attempt"]},
});

export const InterviewModel= mongoose.model("interview", interviewSchema);