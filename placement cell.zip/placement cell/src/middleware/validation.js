import {body,validationResult} from "express-validator";


export const validate=async(req, res, next)=>{
const rules=[
    body("name").isLength({min:1}).withMessage("name is required"),
    body("number").isLength({min:10}).withMessage("Enter a valid number"),
    body("email").isEmail().withMessage("Enter a valid email"),
    body("password").isLength({min:8}).withMessage("Password should have atleast 8 character")
]

await Promise.all(rules.map((rule)=>rule.run(req)));
let validation= validationResult(req);

if(!validation.isEmpty()){
    res.render("userView",{errormsg: validation.array()[0].msg});
}else{
next();
}
};

export const validateStudent=async(req,res,next)=>{
    const rules=[
        body("name").isLength({min:1}).withMessage("name should not empty"),
        body("batch").isLength({min:4, max:4}).withMessage("invalid year"),
        body("college").isLength({min:1}).withMessage("college should not be empty"),
        body("status").isLength({min:1}).withMessage("status should not empty"),
        body("DSAscore").isLength({min:1}).withMessage("DSAScore does not empty"),
        body("webDscore").isLength({min:1}).withMessage("WebDScore does not empty"),
        body("reactScore").isLength({min:1}).withMessage("ReactScore does not empty"),
    ]
    await Promise.all(rules.map((rule)=>rule.run(req)));
let validation= validationResult(req);

if(!validation.isEmpty()){
    res.render("addStudent",{errormsg: validation.array()[0].msg});
}else{
next();
}
};

export const validateInterview=async(req,res,next)=>{
    const rules=[
        body("result").isLength({min:1}).withMessage("result should not empty"),
        body("company").isLength({min:1}).withMessage("company should not empty"),
    ]
    await Promise.all(rules.map((rule)=>rule.run(req)));
let validation= validationResult(req);

if(!validation.isEmpty()){
    res.render("addInterview",{errormsg: validation.array()[0].msg});
}else{
next();
}
};