import jwt from "jsonwebtoken";
import { userController } from "../controller/user.controller.js";

export const auth=(req,res, next)=>{
    const token= req.headers["authorization"];
    if(!token){
        res.status(401).send("invalid user");
    }else{
    try{
        jwt.verify(token, process.env.JWT_KEY);
    }catch(err){
        res.status(401).send("invalid user");
    }
    next();
}      
}