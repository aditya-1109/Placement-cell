import { InterviewModel } from "../model/interview.schema.js";
import {  studentModel } from "../model/student.schema.js";
import { downloadResources } from "../middleware/download.js";
import _ from "lodash";

export class studentController{
    static getStudent=async(req, res)=>{
        const student= await studentModel.find();
        res.render("studentView", {student: student});
    }

    static addStudent= (req,res)=>{
      const errormsg="";
        res.render("addStudent", {errormsg:errormsg});
    }
    static postAddStudent=async(req, res)=>{
      const {name, batch,college, status, DSAscore, webDscore, reactScore}=req.body;
        const student= new studentModel({"name": name,"batch":batch,"college":college,"status":status, "score.DSAscore":DSAscore,"score.webDscore":webDscore, "score.reactScore":reactScore});
        await student.save();
        res.redirect("/student");
    }

    static getInterview=async(req, res)=>{
        const {id}= req.params;
        const interview= await InterviewModel.find({studentID: id});
        res.render("interview", {interview: interview});
    }

    static addInterview= (req, res)=>{
      const errormsg="";
        res.render("addInterview", {errormsg: errormsg});
    }

    static postAddInterview=async(req, res)=>{
        const interview= new InterviewModel(req.body);
        await interview.save();
        res.redirect(`/interview/${interview.studentID}`);
    }

    static download=async(req, res)=>{
        const {id}= req.params;
        const fields=[
            {
                label: 'Name',
                value: 'name'
              },
              {
                label: 'Batch',
                value: 'batch'
              },
              {
               label: 'College',
                value: 'college'
              },
              {
                label: "Status",
                value: "status"
              },
              {
                label: "DSA Score",
                value: "score.DSAscore"
              },
              {
                label: "Web Development Score",
                value: "score.webDscore"
              },
              {
                label: "React Score",
                value: "score.reactScore"
              },
              
        ]
        const data= await studentModel.find({_id:id});
        downloadResources(res, "user.csv", fields, data);
    }

    static downloadInterview=async (req, res)=>{
      const {id}= req.params;
        const fields=[
          {
            label: "StudentID",
            value: "studentID"
          },
          {
            label: "Date",
            value: "Date"
          },
          {
            label: "Company",
            value: "company"
          },
          {
            label: "Result",
            value: "result"
          }
        ]
        const data=await InterviewModel.find({_id: id});
        downloadResources(res, "userInterview.csv", fields, data);
    }

    static downloadStudent= async(req, res)=>{
        const fields=[
            {
                label: 'Name',
                value: 'name'
              },
              {
                label: 'Batch',
                value: 'batch'
              },
              {
               label: 'College',
                value: 'college'
              },
              {
                label: "Status",
                value: "status"
              },
              {
                label: "DSA Score",
                value: "score.DSAscore"
              },
              {
                label: "Web Development Score",
                value: "score.webDscore"
              },
              {
                label: "React Score",
                value: "score.reactScore"
              },
              
        ]
        const data= await studentModel.find();
        downloadResources(res, "user.csv", fields, data);
    }

    static downloadAllInterview=async (req, res)=>{
        const fields=[
          {
            label: "StudentID",
            value: "studentID"
          },
          {
            label: "Date",
            value: "Date"
          },
          {
            label: "Company",
            value: "company"
          },
          {
            label: "Result",
            value: "result"
          }
        ]
        const data=await InterviewModel.find();
        downloadResources(res, "userInterview.csv", fields, data);
      }
}