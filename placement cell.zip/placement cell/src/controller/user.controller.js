import { userModel } from "../model/user.Schema.js";
import jwt from "jsonwebtoken";

export class userController{

    static getRegister=(req,res)=>{
        const errormsg="";
        res.render("userView", {errormsg: errormsg});
    }
    static postRegister=async(req,res)=>{
        const {email}= req.body;
        const useremail=await userModel.findOne({"email":email});
        if(useremail){
            res.redirect("/login");
        }else{
        const user= new userModel(req.body);
        await user.save();
        res.redirect("/login");
        }
    }
    static getLogin=(req, res)=>{
        const message="";
        res.render("login", {message: message});
    }
    
    static postLogin=async(req,res)=>{
        const{email,password}=req.body;
        let key= process.env.JWT_KEY;
        const user=await userModel.findOne({"email":email});
        if(user.password==password){
            const token=jwt.sign({email: user.email }, key,{expiresIn: "1800s"});
            res.redirect("/student");
        }else{
            res.status(404).send("invalid user");
        }
    }
}