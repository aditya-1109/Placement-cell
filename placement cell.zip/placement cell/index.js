import express from "express";
import path from "path";
import dotenv from "dotenv";
import mongoose from "mongoose";
import { validate, validateStudent,validateInterview } from "./src/middleware/validation.js";
import expressLayouts from "express-ejs-layouts";
import { userController } from "./src/controller/user.controller.js";
import { studentController } from "./src/controller/student.controller.js";
import { auth } from "./src/middleware/auth.js";

const server=express();
dotenv.config();
let port= process.env.PORT;

mongoose.connect("mongodb://localhost:27017/job");

server.set("view engine", "ejs");
server.use(expressLayouts);
server.set("views", path.join(path.resolve(),"src", "view"));
server.use(express.static("src/view"));

server.use(express.urlencoded({"extended":false}));

server.get("/",userController.getRegister);
server.post("/",validate, userController.postRegister);
server.get("/login",userController.getLogin);
server.post("/login",userController.postLogin);

server.get("/student",studentController.getStudent);
server.get("/interview/:id", studentController.getInterview);

server.get("/addStudent", studentController.addStudent);
server.post("/addStudent",validateStudent, studentController.postAddStudent);

server.get("/addInterview", studentController.addInterview);
server.post("/addInterview",validateInterview, studentController.postAddInterview);
server.get("/download/:id", studentController.download);
server.get("/downloadInterview/:id", studentController.downloadInterview);
server.get("/downloadStudents", studentController.downloadStudent);
server.get("/downloadAllInterview", studentController.downloadAllInterview);

server.listen(port,()=>{
    console.log("server is listening at 3000");
});